(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 2184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app),
  "getServerSideProps": () => (/* binding */ _app_getServerSideProps)
});

// EXTERNAL MODULE: ./styles/Nav.module.scss
var Nav_module = __webpack_require__(1877);
var Nav_module_default = /*#__PURE__*/__webpack_require__.n(Nav_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/NavIcon.js





const NavIcon = ({
  toggleMenu,
  toggled,
  iconColor
}) => {
  const style = {
    stroke: iconColor
  };
  return /*#__PURE__*/jsx_runtime_.jsx("button", {
    className: `${(Nav_module_default()).menu} ${toggled ? (Nav_module_default()).opened : ""}`,
    onClick: toggleMenu,
    "aria-expanded": toggled ? true : false,
    "aria-label": "Main Menu",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
      width: "50",
      height: "50",
      viewBox: "0 0 100 100",
      children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
        style: style,
        className: `${(Nav_module_default()).line} ${(Nav_module_default()).line1}`,
        d: "M 20,29.000046 H 80.000231 C 80.000231,29.000046 94.498839,28.817352 94.532987,66.711331 94.543142,77.980673 90.966081,81.670246 85.259173,81.668997 79.552261,81.667751 75.000211,74.999942 75.000211,74.999942 L 25.000021,25.000058"
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        style: style,
        className: `${(Nav_module_default()).line} ${(Nav_module_default()).line2}`,
        d: "M 20,50 H 80"
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        style: style,
        className: `${(Nav_module_default()).line} ${(Nav_module_default()).line3}`,
        d: "M 20,70.999954 H 80.000231 C 80.000231,70.999954 94.498839,71.182648 94.532987,33.288669 94.543142,22.019327 90.966081,18.329754 85.259173,18.331003 79.552261,18.332249 75.000211,25.000058 75.000211,25.000058 L 25.000021,74.999942"
      })]
    })
  });
};

/* harmony default export */ const components_NavIcon = (NavIcon);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(4651);
// EXTERNAL MODULE: ./locales/ar.js
var ar = __webpack_require__(256);
// EXTERNAL MODULE: ./locales/en.js
var en = __webpack_require__(2054);
;// CONCATENATED MODULE: ./components/Logo.js








const Logo = ({
  textColor,
  above
}) => {
  const router = (0,client_router.useRouter)();
  const t = router.locale === "en" ? en.en : ar.ar;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Nav_module_default()).nav_logo,
    style: {
      zIndex: above ? `${99999}` : `${1}`
    },
    children: [" ", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/",
      passHref: true,
      children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
        style: {
          color: textColor
        },
        children: t.common.logo
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {})]
  });
};

/* harmony default export */ const components_Logo = (Logo);
// EXTERNAL MODULE: ./styles/Footer.module.scss
var Footer_module = __webpack_require__(4619);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./styles/Menu.module.scss
var Menu_module = __webpack_require__(2341);
var Menu_module_default = /*#__PURE__*/__webpack_require__.n(Menu_module);
// EXTERNAL MODULE: ./stores/AuthStore.js + 1 modules
var AuthStore = __webpack_require__(7297);
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__(5998);
;// CONCATENATED MODULE: ./components/Menu.js
/* eslint-disable @next/next/no-img-element */













const Menu = ({
  toggled,
  toggleMenu,
  jwt
}) => {
  const router = (0,client_router.useRouter)();
  const t = router.locale === "en" ? en.en : ar.ar;
  const authStore = (0,AuthStore/* default */.Z)();
  const cookies = (0,external_nookies_.parseCookies)();

  const handleLogout = () => {
    console.log("logged out");
    authStore.logout();
    authStore.setJWT(null);
    (0,external_nookies_.destroyCookie)(null, "jwt", {
      path: "/"
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `${(Menu_module_default()).menu} ${toggled ? (Menu_module_default()).toggled : ""}`,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
      className: `${(Menu_module_default()).links} ${toggled ? (Menu_module_default()).fadeIn : ""}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
        onClick: toggleMenu,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: t.common.menu[0]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        onClick: toggleMenu,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/forum",
          children: t.common.menu[1]
        })
      }), cookies.jwt ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/reports",
            children: t.common.menu[2]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/dataforchange",
            children: t.common.menu[3]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/spaces",
            children: t.common.menu[4]
          })
        })]
      }) : null]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `${(Menu_module_default()).socials} ${toggled ? (Menu_module_default()).fadeIn : ""}`,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Menu_module_default()).users,
        children: [!cookies.jwt ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
            onClick: toggleMenu,
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/register",
              children: t.common.newAccount
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            onClick: toggleMenu,
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/signin",
              children: t.common.login
            })
          })]
        }) : /*#__PURE__*/jsx_runtime_.jsx("li", {
          style: {
            cursor: "pointer"
          },
          onClick: () => handleLogout(),
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: t.common.logout
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/contact",
            children: t.common.contactUs
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Menu_module_default()).translation,
        children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/en",
            locale: "en",
            children: "English"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            locale: "ar",
            children: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629"
          })
        })]
      })]
    })]
  });
};

async function getServerSideProps(ctx) {
  const jwt = parseCookies(ctx).jwt !== undefined ? parseCookies(ctx.jwt) : null;
  /* const api = process.env.NEXT_PUBLIC_API_URL;
  const res = await fetch(`${api}/dfc`);
  const content = await res.json(); */

  return {
    props: {
      // serverContent: content,
      jwt: jwt
    }
  };
}
/* harmony default export */ const components_Menu = (Menu);
;// CONCATENATED MODULE: ./components/Layout.js
/* eslint-disable @next/next/no-img-element */














function disableScroll() {
  // Get the current page scroll position
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

  window.onscroll = function () {
    window.scrollTo(scrollLeft, scrollTop);
  };
}

function enableScroll() {
  window.onscroll = function () {};
}

const Layout = ({
  children
}) => {
  const router = (0,client_router.useRouter)();
  const t = router.locale === "en" ? en.en : ar.ar;
  const {
    0: iconColor,
    1: setIconColor
  } = (0,external_react_.useState)("#48A470");
  const {
    0: toggled,
    1: setToggled
  } = (0,external_react_.useState)(false);

  const toggleMenu = () => {
    if (!toggled) {
      setToggled(true);
      disableScroll();
      setIconColor("#fff");
      setTimeout(() => {
        // To delay changing the color of the Logo and Menu Icon to make it show like it's transitioning
        document.querySelector("nav").classList.toggle((Nav_module_default()).toggled);
      }, 500);
    } else {
      // Here i'm not delaying the transition when the menu's closing.
      setIconColor("#48A470");
      setToggled(false);
      enableScroll();
      document.querySelector("nav").classList.toggle((Nav_module_default()).toggled);
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_Menu, {
      toggled: toggled,
      toggleMenu: toggleMenu
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
      className: (Nav_module_default()).nav,
      children: [/*#__PURE__*/jsx_runtime_.jsx(components_NavIcon, {
        toggleMenu: toggleMenu,
        iconColor: iconColor,
        toggled: toggled
      }), /*#__PURE__*/jsx_runtime_.jsx(components_Logo, {
        above: true
      })]
    }), children, /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
      className: (Footer_module_default()).footer,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).footer_main,
        children: [/*#__PURE__*/jsx_runtime_.jsx(components_Logo, {
          textColor: "#fff"
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/forum",
          passHref: true,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/forum.png",
            alt: "Forum",
            height: "80",
            width: "65"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (Footer_module_default()).links,
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            children: t.common.footer.linksTitle
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: t.common.footer.links[0]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/about",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: t.common.footer.links[1]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/dataforchange",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: t.common.footer.links[2]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/reports",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: t.common.footer.links[3]
            })
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: t.common.copyrights
      })]
    })]
  });
};

/* harmony default export */ const components_Layout = (Layout);
;// CONCATENATED MODULE: external "next/dist/shared/lib/head"
const head_namespaceObject = require("next/dist/shared/lib/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: ./pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




/* 
TODO: 
  Pages: Homepage, About, Reports, Open Spaces, Contact, DFC, Registration Page, Login Page.
TODO: 
  Components: Layout wrapper, Nav Component, Menu, Footer, PrimaryBtn, SecondaryBtn, HomeSlider, HomeSlider Item, Documents, Documents Item, OpenSpace Component  
*/




function MyApp({
  Component,
  pageProps,
  jwt
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(components_Layout, {
    jwt: jwt,
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1.0"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))]
  });
}

async function _app_getServerSideProps(ctx) {
  console.log(jwt);
  const jwt = parseCookies(ctx).jwt !== undefined ? parseCookies(ctx.jwt) : null;
  return {
    props: {
      jwt: jwt
    }
  };
}
/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 7297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AuthStore)
});

;// CONCATENATED MODULE: external "zustand"
const external_zustand_namespaceObject = require("zustand");
var external_zustand_default = /*#__PURE__*/__webpack_require__.n(external_zustand_namespaceObject);
;// CONCATENATED MODULE: ./stores/AuthStore.js

const useAuth = external_zustand_default()(set => ({
  authenticated: false,
  jwt: null,
  login: () => set(() => ({
    authenticated: true
  })),
  logout: () => set(() => ({
    authenticated: false
  })),
  setJWT: token => set(() => ({
    jwt: token
  }))
}));
/* harmony default export */ const AuthStore = (useAuth);

/***/ }),

/***/ 4619:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__1KW17",
	"footer_main": "Footer_footer_main__2MiFD",
	"links": "Footer_links__zdlrj"
};


/***/ }),

/***/ 2341:
/***/ ((module) => {

// Exports
module.exports = {
	"menu": "Menu_menu__161Su",
	"links": "Menu_links__KKHFI",
	"socials": "Menu_socials__Om7vz",
	"accounts": "Menu_accounts__1p-L-",
	"icon": "Menu_icon__1Nmfy",
	"users": "Menu_users__2-KEN",
	"toggled": "Menu_toggled__1S5KS",
	"fadeIn": "Menu_fadeIn__3uOJd",
	"translation": "Menu_translation__1ap7D",
	"fade-in": "Menu_fade-in__2JR67"
};


/***/ }),

/***/ 1877:
/***/ ((module) => {

// Exports
module.exports = {
	"nav": "Nav_nav__vO801",
	"nav_logo": "Nav_nav_logo__1PhwV",
	"toggled": "Nav_toggled__2rVQY",
	"menu": "Nav_menu__1lkDP",
	"line": "Nav_line__2A7oF",
	"line1": "Nav_line1__2uKVH",
	"line2": "Nav_line2__R-Bor",
	"line3": "Nav_line3__MO8sH",
	"opened": "Nav_opened__3kwcT"
};


/***/ }),

/***/ 5675:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(9917)


/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 5998:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [920,664,917,670], () => (__webpack_exec__(2184)));
module.exports = __webpack_exports__;

})();