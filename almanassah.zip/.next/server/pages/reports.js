(() => {
var exports = {};
exports.id = 53;
exports.ids = [53];
exports.modules = {

/***/ 3545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ reports),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(4651);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__(5998);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./locales/ar.js
var ar = __webpack_require__(256);
// EXTERNAL MODULE: ./locales/en.js
var en = __webpack_require__(2054);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./api/content.js



const hero_info = {
  bimonthly: `يعمل فريق التنسيق على مشاركة المساهمين/ات بالمنتدي و الفاعلين/ات بالمجتمع المدني على تقارير نصف شهري ( كل 14 يوما ) ، تتناول أهم التحديثات المتصلة بـــــــ : السياق السياسي - الأوضاع الاقتصادية - الأوضاع الأمنية - تحديثات المتصلة بالمجتمع المدني و المجموعات القاعدية - القضايا الطارئة. وذلك بمناطق عمل المنتدى التفاكري المختلفة (ولايات إقليم دارفور - ولايات إقليم شرق السودان - ولاية جنوب كردفان " مناطق سيطرة الحكومة السودانية " - ولاية النيل الأزرق " مناطق سيطرة الحكومة السودانية " - مناطق سيطرة الحركة الشعبية لتحرير السودان - شمال، في ولايتي " النيل الأزرق وجنوب كردفان ").`,
  advocacy: `تستعرض هذه النشرة التي يتم اصدارها كل شهرين بواسطة فريق التنسيق للمنتدى، أهم القضايا التي تتطلب تدخلات عاجلة ومناصرة بواسطة المجتمع المدني على المستوى الوطني او الاقليمي، أو ذوي الصلة من المنظمات الدولية، والتي يتم التوصل إليها من خلال تحليل نتائج توصيات الاجتماعات والأنشطة الإقليمية والولائية التي يتم تنفيذها بواسطة فريق التنسيق بمناطق عمله، أيضا من خلال المقابلات و الجلسات التشاورية مع مساهمي المنتدي و الفاعلين/ات بالمجتمع المدني `,
  meetings: `يقوم المنتدى التفاكري بإصدار نشرة ربع سنوية تتناول إحدى القضايا الفاعلة و المؤثرة على المستوى الوطني من خلال إجراء مقابلات و جلسات تشاورية لاستطلاع آراء مساهمين/ات المنتدى او الفاعلين/ات بهذه القضايا. `,
  monthly: `من خلال هذه النشرة يقوم فريق التنسيق للمنتدى التفاكري، باستعراض أهم القضايا الطارئة والمستجدات المتصلة بالأوضاع في مناطق سيطرة الحكومة السودانية ومناطق سيطرة حركات الكفاح المسلح، حيث تحوي هذه النشرات اهم التحليلات المتصلة بالأوضاع السياسية والاقتصادية والأمنية والقضايا الطارئة من وجهة نظر مساهمي /ات المنتدى و الفاعلين/ات بالمجتمع المدني بهذه المناطق. `
};
const types = ["نشرات شهرية", "مناصرة", "إجتماعات", "وثائق تتصل بالإنتقال"];
const locations = ["النيل الأزرق", "دارفور", "قومية", "جنوب كردفان", "الشرق"];
const years = [2021, 2020];
const months = ["يناير", "فبراير", "مارس", "ابريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "اكتوبر", "نوفمبر", "ديسمبر"];
const documents = [{
  title: "إسم المستند",
  type: "نصف شهري",
  subtype: "النيل الأزرق",
  month: "يونيو",
  year: 2021,
  filter: ["bimonthly", "jun", "BN", 2020],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "نصف شهري",
  subtype: "النيل الأزرق",
  month: "يونيو",
  year: 2020,
  filter: ["bimonthly", "june", "BN", 2020],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "شهري",
  subtype: "النيل الأزرق",
  month: "يوليو",
  year: 2020,
  filter: ["bimonthly", "june", "BN", 2020],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "شهري",
  subtype: "النيل الأزرق",
  month: "يوليو",
  year: 2020,
  filter: ["bimonthly", "june", "BN", 2020],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "شهري",
  subtype: "دارفور",
  month: "يناير",
  year: 2020,
  filter: ["bimonthly", "june", "BN", 2020],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "شهري",
  subtype: "دارفور",
  month: "يناير",
  year: 2021,
  filter: ["bimonthly", "june", "BN", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "شهري",
  subtype: "دارفور",
  month: "فبراير",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "شهري",
  subtype: "دارفور",
  month: "فبراير",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "مناصرة",
  subtype: "دارفور",
  month: "مارس",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "نصف شهري",
  subtype: "دارفور",
  month: "مارس",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "إجتماعات",
  subtype: "قومية",
  month: "أغسطس",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "الإنتقالية",
  subtype: "قومية",
  month: "أغسطس",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "الإنتقالية",
  subtype: "قومية",
  month: "ديسمبر",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}, {
  title: "إسم المستند",
  type: "نصف شهري",
  subtype: "قومية",
  month: "ديسمبر",
  year: 2021,
  filter: ["monthly", "national", "aug", 2021],
  img: "/images/documentImage.png"
}];
// EXTERNAL MODULE: ./styles/Filter.module.scss
var Filter_module = __webpack_require__(2947);
var Filter_module_default = /*#__PURE__*/__webpack_require__.n(Filter_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Filter.js
/* eslint-disable @next/next/no-img-element */





const Filter = ({
  title,
  items,
  toggleFilter,
  selectFilter
}) => {
  const chooseFilter = e => {
    e.target.parentNode.parentNode.parentNode.classList.toggle((Filter_module_default()).shown);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Filter_module_default()).filter,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
      className: `${(Filter_module_default()).btn}`,
      children: [title, /*#__PURE__*/jsx_runtime_.jsx("img", {
        onClick: e => toggleFilter(e),
        src: "/icons/downArrow.svg",
        alt: "",
        width: "20",
        height: "10"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Filter_module_default()).list,
      children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
        className: title == "الشهر" ? (Filter_module_default()).grid : "",
        children: items.map((item, i) => /*#__PURE__*/jsx_runtime_.jsx("option", {
          value: item,
          onClick: e => {
            chooseFilter(e);
            selectFilter(e);
          },
          children: item
        }, `${item}-i`))
      })
    })]
  });
};

/* harmony default export */ const components_Filter = (Filter);
// EXTERNAL MODULE: ./node_modules/next/dist/client/image.js
var client_image = __webpack_require__(9917);
;// CONCATENATED MODULE: ./public/icons/documentIcon.svg
/* harmony default export */ const documentIcon = ({"src":"/_next/static/image/public/icons/documentIcon.2e283b35116ac5ce728209c82c937703.svg","height":493,"width":393});
// EXTERNAL MODULE: ./styles/ReportDocument.module.scss
var ReportDocument_module = __webpack_require__(3491);
var ReportDocument_module_default = /*#__PURE__*/__webpack_require__.n(ReportDocument_module);
;// CONCATENATED MODULE: ./components/ReportDocument.js






const ReportDocument = ({
  type,
  title,
  img,
  month,
  year
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (ReportDocument_module_default()).report,
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      children: type
    }), /*#__PURE__*/jsx_runtime_.jsx(client_image.default, {
      src: documentIcon,
      alt: title,
      width: "100",
      height: "100"
    }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
      children: title
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
      children: [month, ", ", year]
    })]
  });
};

/* harmony default export */ const components_ReportDocument = (ReportDocument);
// EXTERNAL MODULE: ./styles/Reports.module.scss
var Reports_module = __webpack_require__(861);
var Reports_module_default = /*#__PURE__*/__webpack_require__.n(Reports_module);
;// CONCATENATED MODULE: ./pages/reports.js
/* eslint-disable @next/next/no-img-element */

















const Reports = ({
  serverData
}) => {
  const router = (0,client_router.useRouter)();
  const t = router.locale === "en" ? en.en : ar.ar;
  const {
    0: selectedTitle,
    1: setSelectedTitle
  } = (0,external_react_.useState)(null);
  const {
    0: content,
    1: setContent
  } = (0,external_react_.useState)(documents);
  console.log(serverData); // const jwtt = parseCookies().jwt

  /* 	useEffect(() => {
  	axios
  		.get(`${process.env.NEXT_PUBLIC_API_URL}/reports`, {
  			headers: {
  				Authorization: `Bearer ${jwtt}`,
  			},
  		})
  		.then((res) => {
  			console.log(res);
  		})
  		.catch((err) => {
  			console.error(err);
  		});
  }, []); */

  const selectTitle = e => {
    const title = e.target;

    if (title.tagName == "H1") {
      if (selectedTitle) {
        selectedTitle.classList.remove((Reports_module_default()).selected);
        title.parentNode.classList.add((Reports_module_default()).selected);
        setSelectedTitle(title.parentNode);
      } else {
        setSelectedTitle(title.parentNode);
        title.parentNode.classList.add((Reports_module_default()).selected);
      }
    }
  };

  const filterContent = e => {
    const filter = e.target.value;

    if (filter === "all") {
      setContent(documents);
    } else {
      setContent(documents);

      if (types.indexOf(filter) !== -1) {
        setContent(documents.filter(doc => doc.type === filter));
      }

      if (locations.indexOf(filter) !== -1) {
        setContent(documents.filter(doc => doc.subtype === filter));
      }

      if (years.indexOf(Number(filter)) !== -1) {
        setContent(documents.filter(doc => doc.year === Number(filter)));
      }

      if (months.indexOf(filter) !== -1) {
        setContent(documents.filter(doc => doc.month === filter));
      }
    }
  };

  const toggleFilter = e => {
    e.target.parentNode.parentNode.classList.toggle((Filter_module_default()).shown);
  };
  /* 	useEffect(() => {
  		axios
  			.get(`${process.env.NEXT_PUBLIC_API_URL}/reports`, {
  				headers: { Authorization: `Bearer ${jwt}` },
  			})
  			.then((res) => {
  				console.log(res);
  			})
  			.catch((error) => {
  				console.error(error);
  			});
  	}, []); */


  console.log(t.reports.advocacyDescription);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "\u062A\u0642\u0627\u0631\u064A\u0631 \u0627\u0644\u0645\u0646\u062A\u062F\u0649"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("main", {
      className: (Reports_module_default()).main,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: (Reports_module_default()).hero,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Reports_module_default()).hero_info,
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            children: selectedTitle ? t.reports[`${selectedTitle.id}Description`] : t.reports.heroStockDescription
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (Reports_module_default()).hero_titles,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (Reports_module_default()).title,
            id: "monthly",
            onClick: e => selectTitle(e),
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              children: t.reports.monthly
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (Reports_module_default()).arrow,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/icons/arrow.svg",
                alt: "Arrow",
                height: "25",
                width: "20"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (Reports_module_default()).title,
            id: "advocacy",
            onClick: e => selectTitle(e),
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              children: t.reports.advocacy
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (Reports_module_default()).arrow,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/icons/arrow.svg",
                alt: "Arrow",
                height: "25",
                width: "20"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (Reports_module_default()).title,
            id: "special",
            onClick: e => selectTitle(e),
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              children: t.reports.special
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (Reports_module_default()).arrow,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/icons/arrow.svg",
                alt: "Arrow",
                height: "25",
                width: "20"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (Reports_module_default()).title,
            id: "bimonthly",
            onClick: e => selectTitle(e),
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              children: t.reports.bimonthly
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (Reports_module_default()).arrow,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/icons/arrow.svg",
                alt: "Arrow",
                height: "25",
                width: "20"
              })
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: (Reports_module_default()).description,
        children: t.reports.libraryDescription
      }),  true ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: (Reports_module_default()).documents,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (Reports_module_default()).documents_filters,
          children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
            className: `${(Reports_module_default()).btn} ${(Reports_module_default()).btnAll}`,
            onClick: e => filterContent(e),
            value: "all",
            children: t.reports.libraryFilters[0]
          }), /*#__PURE__*/jsx_runtime_.jsx(components_Filter, {
            items: types,
            title: t.reports.libraryFilters[1],
            toggleFilter: toggleFilter,
            selectFilter: filterContent
          }), /*#__PURE__*/jsx_runtime_.jsx(components_Filter, {
            title: t.reports.libraryFilters[2],
            items: locations,
            toggleFilter: toggleFilter,
            selectFilter: filterContent
          }), /*#__PURE__*/jsx_runtime_.jsx(components_Filter, {
            title: t.reports.libraryFilters[3],
            items: years,
            toggleFilter: toggleFilter,
            selectFilter: filterContent
          }), /*#__PURE__*/jsx_runtime_.jsx(components_Filter, {
            title: t.reports.libraryFilters[4],
            items: months,
            toggleFilter: toggleFilter,
            selectFilter: filterContent
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Reports_module_default()).documents_content,
          children: content.map((doc, i) => /*#__PURE__*/jsx_runtime_.jsx(components_ReportDocument, {
            title: doc.title,
            img: doc.img,
            type: doc.type,
            subtype: doc.subtype,
            month: doc.month,
            year: doc.year
          }, `${doc.title}-${i}`))
        })]
      }) : /*#__PURE__*/0]
    })]
  });
}; // const {publicRuntimeConfig} = getConfig();
// console.log(publicRuntimeConfig);


async function getStaticProps() {
  const jwt = (0,external_nookies_.parseCookies)().jwt;
  await external_axios_default().get("https://admin.almanassah-sd.org/reports", {
    headers: {
      Authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwiaWF0IjoxNjQwNjI1MzAxLCJleHAiOjE2NDMyMTczMDF9.rxK_wwxK-jHhm_kLgmpiHa-tzYDy3rrwdUY7znmYubc`
    }
  }).then(resp => {
    console.log(resp);
    return resp;
  }).catch(error => {
    console.error(`Error from server is: ${error}`);
  });
  return {
    props: {
      serverData: 'hello'
    }
  };
}
/* harmony default export */ const reports = (Reports);

/***/ }),

/***/ 2947:
/***/ ((module) => {

// Exports
module.exports = {
	"filter": "Filter_filter__3ddyQ",
	"btn": "Filter_btn__17pxH",
	"list": "Filter_list__zW4Ci",
	"shown": "Filter_shown__5ryKt",
	"grid": "Filter_grid__1zoPW"
};


/***/ }),

/***/ 3491:
/***/ ((module) => {

// Exports
module.exports = {
	"report": "ReportDocument_report__1ps1v"
};


/***/ }),

/***/ 861:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Reports_main__3o4tQ",
	"hero": "Reports_hero__15J8s",
	"hero_info": "Reports_hero_info__lUpz9",
	"hero_titles": "Reports_hero_titles__17l6e",
	"title": "Reports_title__2ynCa",
	"arrow": "Reports_arrow__2FnFg",
	"selected": "Reports_selected__IFuxM",
	"description": "Reports_description__1Z7yw",
	"documents_filters": "Reports_documents_filters__3QoGt",
	"btn": "Reports_btn__ImQF8",
	"btnAll": "Reports_btnAll__1LkmE",
	"documents_content": "Reports_documents_content__1vAoj"
};


/***/ }),

/***/ 2376:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 5998:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [920,664,917,670], () => (__webpack_exec__(3545)));
module.exports = __webpack_exports__;

})();