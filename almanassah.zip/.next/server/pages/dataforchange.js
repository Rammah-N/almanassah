(() => {
var exports = {};
exports.id = 237;
exports.ids = [237];
exports.modules = {

/***/ 8419:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Components_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3222);
/* harmony import */ var _styles_Components_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Components_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const Button = ({
  color,
  bgc,
  children
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("button", {
    className: (_styles_Components_module_scss__WEBPACK_IMPORTED_MODULE_2___default().Btn_plt),
    style: {
      color: color,
      border: bgc ? "none" : `2px solid ${color}`,
      backgroundColor: bgc
    },
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

/***/ }),

/***/ 6805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4398);
/* harmony import */ var _styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1664);
/* harmony import */ var next_dist_client_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9917);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5998);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8419);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4651);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);












const DataForChange = ({
  jwt
}) => {
  const router = (0,next_dist_client_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (!jwt) {
      router.push("/");
    }
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((next_head__WEBPACK_IMPORTED_MODULE_5___default()), {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("title", {
        children: "\u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("main", {
      className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().main),
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("section", {
        className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().hero),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().hero_chart),
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().chart),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              children: "\u0646\u0628\u0630\u0629 \u0639\u0646 \u0627\u0644\u0645\u0634\u0631\u0648\u0639"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
              children: ":\u0639\u062F\u062F \u0627\u0644\u0625\u0633\u062A\u0628\u064A\u0627\u0646\u0627\u062A"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
              children: "150 \u0625\u0633\u062A\u0628\u064A\u0627\u0646 \u0639\u0644\u0649 \u0645\u0631 7 \u0634\u0647\u0648\u0631 \u0641\u064A 11 \u0648\u0644\u0627\u064A\u0629"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().chart_figure),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {})]
            })]
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().hero_info),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
            children: "\u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631 \u0647\u0648 \u0623\u0648\u0644 \u0645\u0634\u0631\u0648\u0639 \u0644\u062C\u0645\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0641\u064A \u0627\u0644\u0633\u0648\u062F\u0627\u0646"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
            children: "\u0627\u0644\u0647\u062F\u0641 \u0645\u0646 \u062E\u0644\u0642\u0646\u0627 \u0644\u0645\u0634\u0631\u0648\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631 \u0647\u0648 \u0644\u062F\u0639\u0645 \u0627\u0644\u0628\u062D\u0648\u062B \u0648\u0644\u062F\u0639\u0645 \u0627\u0644\u062A\u063A\u064A\u064A\u0631 \u0641\u064A \u0627\u0644\u0633\u0648\u062F\u0627\u0646 \u0639\u0646 \u0637\u0631\u064A\u0642 \u062A\u0648\u0641\u064A\u0631 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0643\u0627\u0641\u064A\u0629 \u0644\u062A\u062D\u0642\u064A\u0642 \u0647\u0630\u0647 \u0627\u0644\u0623\u0647\u062F\u0627\u0641"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__.default, {
            href: "/",
            passHref: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("button", {
              children: "\u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0644\u0644\u0628\u0631\u0646\u0627\u0645\u062C"
            })
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("section", {
        className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().features),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          children: "\u0645\u0645\u064A\u0632\u0627\u062A \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().container),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().feature),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              children: "\u0628\u064A\u0627\u0646\u0627\u062A \u062F\u0642\u064A\u0642\u0629"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
              children: "\u0643\u0644 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0645 \u062C\u0645\u0639\u0647\u0627 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u062F\u0642\u064A\u0642\u0629 \u0648\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646\u0647\u0627 \u0645\u0646 \u062E\u0628\u0631\u0627\u0621 \u0645\u062E\u062A\u0635\u064A\u0646 \u0641\u064A \u062C\u0645\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_dist_client_image__WEBPACK_IMPORTED_MODULE_1__.default, {
              width: "90",
              height: "90",
              src: "/icons/accurate.svg",
              alt: "Accurate Icon"
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().feature),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              children: "\u0645\u0648\u0627\u0636\u064A\u0639 \u0645\u062A\u0646\u0648\u0639\u0629"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
              children: "\u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u064A\u062A\u0636\u0645\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0641\u064A \u0639\u062F\u0629 \u0645\u062C\u0627\u0644\u0627\u062A \u0648\u0628\u062A\u0641\u0627\u0635\u064A\u0644 \u0643\u0626\u064A\u0631\u0629 \u0639\u0646 \u0643\u0644 \u0645\u062C\u0627\u0644 \u062A\u062A\u064A\u062D \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0628\u062D\u062B \u0641\u064A \u0639\u062F\u0629 \u0645\u062C\u0627\u0644\u0627\u062A"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_dist_client_image__WEBPACK_IMPORTED_MODULE_1__.default, {
              width: "90",
              height: "90",
              src: "/icons/network.svg",
              alt: "Network Icon"
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().feature),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              children: "\u062A\u062D\u062F\u064A\u062B\u0627\u062A \u062F\u0648\u0631\u064A\u0629"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
              children: "\u0645\u0634\u0631\u0648\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631 \u0645\u0634\u0631\u0648\u0639 \u0645\u0633\u062A\u0645\u0631 \u0648\u0642\u0627\u0626\u0645 \u0639\u0644\u064A\u0647 \u0641\u0631\u064A\u0642 \u0639\u0645\u0644 \u0643\u0628\u064A\u0631 \u062C\u062F\u0627, \u0648\u064A\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u062F\u0648\u0631\u064A\u0627 \u0644\u062A\u0632\u0648\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0623\u0643\u0628\u0631 \u0642\u062F\u0631 \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_dist_client_image__WEBPACK_IMPORTED_MODULE_1__.default, {
              width: "90",
              height: "90",
              src: "/icons/update.svg",
              alt: "Update Icon"
            })]
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("section", {
        className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stats),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stat),
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stat_info),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              children: "\u0628\u062F\u0627\u064A\u0629 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
              children: "\u0645\u0646\u0630 \u0639\u0627\u0645 2017"
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("i", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stat),
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stat_info),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              children: "\u0639\u062F\u062F \u0627\u0644\u0645\u0648\u0627\u0636\u064A\u0639"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
              children: "15 \u0645\u0648\u0636\u0648\u0639 \u0645\u062E\u062A\u0644\u0641"
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("i", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stat),
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().stat_info),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              children: "\u0639\u062F\u062F \u0627\u0644\u0625\u0633\u062A\u0628\u064A\u0627\u0646\u0627\u062A"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
              children: "1500 \u0625\u0633\u062A\u0628\u064A\u0627\u0646"
            })]
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("section", {
        className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().about),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          children: "\u0644\u064A\u0647 \u0639\u0645\u0644\u0646\u0627 \u0645\u0634\u0631\u0648\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631\u061F"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
          children: "\u0639\u0645\u0644\u0646\u0627 \u0645\u0634\u0631\u0648\u0639 \u201C\u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631\u201D \u0639\u0634\u0627\u0646 \u062F\u0627\u064A\u0631\u064A\u0646 \u0646\u0635\u0644\u062D \u0627\u0644\u0628\u0644\u062F \u0648\u0646\u0645\u0634\u064A \u0644\u064A \u0642\u062F\u0627\u0645, \u0648\u0646\u0633\u0627\u0639\u062F \u0641\u064A \u062A\u0637\u0648\u064A\u0631 \u0627\u0644\u0645\u0634\u0627\u0631\u064A\u0639 \u0639\u0646 \u0637\u0631\u064A\u0642 \u062A\u0648\u0641\u064A\u0631 \u0623\u0643\u0628\u0631 \u0643\u0645 \u0645\u0646 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0644\u062A\u062D\u0641\u064A\u0632 \u0627\u0644\u0639\u0645\u0644 \u0648\u0644\u062F\u0639\u0645 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0627\u0644\u0645\u062A\u0639\u0644\u0642\u0629 \u0628\u0647\u0630\u0647 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0628\u0635\u0648\u0631\u0629 \u0645\u0628\u0627\u0634\u0631\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0645\u0628\u0627\u0634\u0631\u0629"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("section", {
        className: (_styles_DFC_module_scss__WEBPACK_IMPORTED_MODULE_8___default().cta),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_Button__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
          text: "\u0625\u0642\u0631\u0623 \u0627\u0644\u0645\u0632\u064A\u062F",
          color: "#FCB03F",
          bgc: "#10324F",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__.default, {
            href: "/reports",
            children: "\u0625\u0642\u0631\u0623 \u0627\u0644\u0645\u0632\u064A\u062F"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
          children: "\u0644\u0648 \u062F\u0627\u064A\u0631 \u062A\u0635\u0644 \u0644\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0647\u0645\u0629 \u0627\u0644\u0645\u062A\u0639\u0644\u0642\u0629 \u0627\u0644\u0645\u062A\u0639\u0644\u0642\u0629 \u0628\u064A \u0645\u0634\u0631\u0648\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u062A\u063A\u064A\u064A\u0631 \u061F \u0645\u0645\u0643\u0646 \u0639\u0646 \u0637\u0631\u064A\u0642 \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0644\u0644\u0645\u0634\u0631\u0648\u0639"
        })]
      })]
    })]
  });
};

async function getServerSideProps(ctx) {
  const jwt = (0,nookies__WEBPACK_IMPORTED_MODULE_2__.parseCookies)(ctx).jwt !== undefined ? (0,nookies__WEBPACK_IMPORTED_MODULE_2__.parseCookies)(ctx.jwt) : null;
  /* const api = process.env.NEXT_PUBLIC_API_URL;
  const res = await fetch(`${api}/dfc`);
  const content = await res.json(); */

  return {
    props: {
      // serverContent: content,
      jwt: jwt
    }
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataForChange);

/***/ }),

/***/ 3222:
/***/ ((module) => {

// Exports
module.exports = {
	"Btn_plt": "Components_Btn_plt__24dZF"
};


/***/ }),

/***/ 4398:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "DFC_main__3LxMf",
	"hero": "DFC_hero__2QsxJ",
	"hero_chart": "DFC_hero_chart__1QjhI",
	"chart": "DFC_chart__1N2U6",
	"chart_figure": "DFC_chart_figure__5fwbQ",
	"hero_info": "DFC_hero_info__13TK9",
	"features": "DFC_features__3TyWL",
	"container": "DFC_container__1F4tt",
	"feature": "DFC_feature__c7xwK",
	"stats": "DFC_stats__3vhZe",
	"stat": "DFC_stat__2FOEW",
	"stat_info": "DFC_stat_info__3xLpp",
	"about": "DFC_about__2Gx6a",
	"cta": "DFC_cta__3MM2n"
};


/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 5998:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [920,664,917], () => (__webpack_exec__(6805)));
module.exports = __webpack_exports__;

})();