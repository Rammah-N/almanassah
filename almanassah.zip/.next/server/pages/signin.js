(() => {
var exports = {};
exports.id = 176;
exports.ids = [176];
exports.modules = {

/***/ 1999:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Loader_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var _styles_Loader_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Loader_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);





const Loader = ({
  size
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: (_styles_Loader_module_scss__WEBPACK_IMPORTED_MODULE_2___default().lds_ring),
    style: {
      transform: `scale(${size})`
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {})]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);

/***/ }),

/***/ 3606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9821);
/* harmony import */ var _styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5998);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stores_AuthStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var _components_Loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1999);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);












const SignIn = ({
  jwt
}) => {
  const {
    0: username,
    1: setUsername
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: password,
    1: setPassword
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: loaded,
    1: setLoaded
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("تسجيل الدخول");
  const authStore = (0,_stores_AuthStore__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)();

  const handleLogin = async e => {
    e.preventDefault();
    const loginInfo = {
      identifier: username,
      password: password
    };
    const login = await fetch(`${"https://admin.almanassah-sd.org"}/auth/local`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(loginInfo)
    });
    const loginResponse = await login.json();

    if (loginResponse.jwt) {
      (0,nookies__WEBPACK_IMPORTED_MODULE_1__.setCookie)(null, "jwt", loginResponse.jwt, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
      });
      authStore.login();
      authStore.setJWT(loginResponse.jwt);
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        setLoaded("!تم تسجيل الدخول بنجاح");
        setTimeout(() => {
          next_router__WEBPACK_IMPORTED_MODULE_2___default().push("/");
        }, 500);
      }, 2000);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (jwt) {
      next_router__WEBPACK_IMPORTED_MODULE_2___default().push("/");
    }
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("main", {
    className: (_styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6___default().register),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
      className: (_styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6___default().container),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: (_styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6___default().slogan),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
          children: "\u0627\u0644\u0645\u0646\u0635\u0629"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        className: (_styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6___default().main),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h2", {
          children: "\u062A\u0633\u062C\u064A\u0644 \u062F\u062E\u0648\u0644"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("p", {
          children: " \u064A\u0645\u0643\u0646\u0643 \u0625\u0633\u062A\u062E\u062F\u0627\u0645 \u0628\u0631\u064A\u062F\u0643 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0644\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("form", {
          onSubmit: e => handleLogin(e),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("input", {
            type: "email",
            placeholder: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
            name: "email",
            required: true,
            onChange: e => setUsername(e.target.value),
            value: username
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("input", {
            type: "password",
            placeholder: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631",
            name: "password",
            onChange: e => setPassword(e.target.value),
            value: password
          }), loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_Loader__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
            size: "0.8"
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("button", {
            type: "submit",
            className: (_styles_Signin_module_scss__WEBPACK_IMPORTED_MODULE_6___default().submit),
            children: loaded
          })]
        })]
      })]
    })
  });
};

async function getServerSideProps(ctx) {
  const jwt = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)(ctx).jwt !== undefined ? (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)(ctx.jwt) : null;
  return {
    props: {
      jwt: jwt
    }
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SignIn);

/***/ }),

/***/ 7297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AuthStore)
});

;// CONCATENATED MODULE: external "zustand"
const external_zustand_namespaceObject = require("zustand");
var external_zustand_default = /*#__PURE__*/__webpack_require__.n(external_zustand_namespaceObject);
;// CONCATENATED MODULE: ./stores/AuthStore.js

const useAuth = external_zustand_default()(set => ({
  authenticated: false,
  jwt: null,
  login: () => set(() => ({
    authenticated: true
  })),
  logout: () => set(() => ({
    authenticated: false
  })),
  setJWT: token => set(() => ({
    jwt: token
  }))
}));
/* harmony default export */ const AuthStore = (useAuth);

/***/ }),

/***/ 1648:
/***/ ((module) => {

// Exports
module.exports = {
	"lds_ring": "Loader_lds_ring__3yXbW"
};


/***/ }),

/***/ 9821:
/***/ ((module) => {

// Exports
module.exports = {
	"register": "Signin_register__2-CM3",
	"container": "Signin_container__6CUr5",
	"slogan": "Signin_slogan__1l296",
	"main": "Signin_main__1jL-V"
};


/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 5998:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3606));
module.exports = __webpack_exports__;

})();