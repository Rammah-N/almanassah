(() => {
var exports = {};
exports.id = 861;
exports.ids = [861];
exports.modules = {

/***/ 3189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ spaces),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/client/image.js
var client_image = __webpack_require__(9917);
// EXTERNAL MODULE: ./node_modules/next/dist/client/link.js
var client_link = __webpack_require__(2167);
// EXTERNAL MODULE: ./styles/SpaceComponent.module.scss
var SpaceComponent_module = __webpack_require__(9749);
var SpaceComponent_module_default = /*#__PURE__*/__webpack_require__.n(SpaceComponent_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Space.js
/* eslint-disable @next/next/no-img-element */






const Space = ({
  title,
  description,
  link,
  img,
  flip,
  map,
  reserveLink
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (SpaceComponent_module_default()).space,
    children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
      src: img,
      alt: `${title} space`
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (SpaceComponent_module_default()).info,
      style: {
        order: flip ? `${1}` : `${2}`
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
        children: title
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: (SpaceComponent_module_default()).info_icons,
        children: [/*#__PURE__*/jsx_runtime_.jsx(client_image.default, {
          src: "/icons/mute.svg",
          alt: "Icon",
          width: "30",
          height: "30"
        }), /*#__PURE__*/jsx_runtime_.jsx(client_image.default, {
          src: "/icons/book.svg",
          alt: "Icon",
          width: "30",
          height: "30"
        }), /*#__PURE__*/jsx_runtime_.jsx(client_image.default, {
          src: "/icons/cable.svg",
          alt: "Icon",
          width: "30",
          height: "30"
        }), /*#__PURE__*/jsx_runtime_.jsx(client_image.default, {
          src: "/icons/wifi.svg",
          alt: "Icon",
          width: "30",
          height: "30"
        })]
      }), map ? /*#__PURE__*/jsx_runtime_.jsx("iframe", {
        src: map,
        style: {
          border: "0",
          width: "100%",
          height: "100%",
          marginTop: "1rem"
        },
        allowFullScreen: "",
        loading: "lazy"
      }) : null]
    })]
  });
};

/* harmony default export */ const components_Space = (Space);
// EXTERNAL MODULE: ./styles/Spaces.module.scss
var Spaces_module = __webpack_require__(3681);
var Spaces_module_default = /*#__PURE__*/__webpack_require__.n(Spaces_module);
// EXTERNAL MODULE: ./styles/Reservation.module.scss
var Reservation_module = __webpack_require__(5279);
var Reservation_module_default = /*#__PURE__*/__webpack_require__.n(Reservation_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(4651);
// EXTERNAL MODULE: ./locales/ar.js
var ar = __webpack_require__(256);
// EXTERNAL MODULE: ./locales/en.js
var en = __webpack_require__(2054);
;// CONCATENATED MODULE: ./components/ReservationForm.js









const Register = () => {
  const router = (0,client_router.useRouter)();
  const t = router.locale === 'ar' ? ar.ar : en.en;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Reservation_module_default()).container,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Reservation_module_default()).slogan,
      children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
        children: t.spaces.bg
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Reservation_module_default()).main,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
        children: t.spaces.reserve
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: t.spaces.reserveDescription
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          placeholder: "\u0627\u0644\u0625\u0633\u0645",
          name: "name",
          required: true
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          placeholder: "\u0627\u0644\u062C\u0647\u0629",
          name: "affinity",
          required: true
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          placeholder: "\u0627\u0644\u0647\u062F\u0641 \u0645\u0646 \u0627\u0644\u062D\u062C\u0632",
          name: "reason",
          required: true
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          children: "\u0625\u062E\u062A\u0631 \u0627\u0644\u0645\u0633\u0627\u062D\u0629"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
          name: "spaces",
          id: "spaces",
          children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "portsudan",
            children: "\u0628\u0648\u0631\u062A\u0633\u0648\u062F\u0627\u0646"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "kordufan",
            children: "\u0643\u0631\u062F\u0641\u0627\u0646"
          }), /*#__PURE__*/jsx_runtime_.jsx("option", {
            value: "darfur",
            children: "\u062F\u0627\u0631\u0641\u0648\u0631"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "email",
          placeholder: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
          name: "email",
          required: true
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "date",
          children: "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062D\u062C\u0632"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "date",
          name: "date"
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "submit",
          className: (Reservation_module_default()).submit,
          children: "\u0627\u0644\u062D\u062C\u0632 \u0627\u0644\u0622\u0646"
        })]
      })]
    })]
  });
};

/* harmony default export */ const ReservationForm = (Register);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__(5998);
;// CONCATENATED MODULE: ./pages/spaces.js











const Spaces = ({
  jwt
}) => {
  const router = (0,client_router.useRouter)();
  const t = router.locale === "ar" ? ar.ar : en.en;
  (0,external_react_.useEffect)(() => {
    if (!jwt) {
      router.push("/");
    }
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("main", {
    className: (Spaces_module_default()).spaces,
    children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
      className: (Spaces_module_default()).title,
      children: t.spaces.title
    }), /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: (Spaces_module_default()).description,
      children: t.spaces.description
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
      className: (Spaces_module_default()).container,
      children: [/*#__PURE__*/jsx_runtime_.jsx(components_Space, {
        img: "/images/space-1.png",
        title: t.spaces.spacesTitles[0],
        description: "\u0646\u0635 \u062A\u0639\u0631\u064A\u0641\u064A \u064A\u062A\u0643\u0644\u0645 \u0639\u0646 \u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0647\u062F\u0641 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0644\u0645\u0627\u0630\u0627 \u062A\u0645 \u0635\u0646\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u062A\u0648\u0636\u064A\u062D \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0627\u0644\u0632\u0627\u0626\u0631 \u0639\u0646 \u0645\u0627\u0647\u064A\u0629 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
        link: "/register",
        map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3843.001992850757!2d32.534942214852386!3d15.59154238917761!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x168e8f25a1e6c1ed%3A0x4237596ff94f2030!2zQWRlZWxhIEZvciBDdWx0dXJlIGFuZCBBcnRzINi52K_ZitmE2Kkg2YTZhNir2YLYp9mB2Kkg2YjYp9mE2YHZhtmI2YY!5e0!3m2!1sen!2s!4v1640500133306!5m2!1sen!2s"
      }), /*#__PURE__*/jsx_runtime_.jsx(components_Space, {
        img: "/images/space-2.png",
        title: t.spaces.spacesTitles[1],
        description: "\u0646\u0635 \u062A\u0639\u0631\u064A\u0641\u064A \u064A\u062A\u0643\u0644\u0645 \u0639\u0646 \u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0647\u062F\u0641 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0644\u0645\u0627\u0630\u0627 \u062A\u0645 \u0635\u0646\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u062A\u0648\u0636\u064A\u062D \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0627\u0644\u0632\u0627\u0626\u0631 \u0639\u0646 \u0645\u0627\u0647\u064A\u0629 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
        link: "/register",
        flip: true,
        map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.9387588992927!2d29.652961914812526!3d12.047734691466667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x16e89103eb4e5fef%3A0x7d66b9a17a376e0e!2z2YXYsdmD2LIg2K_Ysdin2LPYp9iqINin2YTYs9mE2KfZhdiMINis2KfZhdi52Kkg2KfZhNiv2YTZhtis!5e0!3m2!1sen!2s!4v1640500748257!5m2!1sen!2s"
      }), /*#__PURE__*/jsx_runtime_.jsx(components_Space, {
        img: "/images/space-3.png",
        title: t.spaces.spacesTitles[2],
        description: "\u0646\u0635 \u062A\u0639\u0631\u064A\u0641\u064A \u064A\u062A\u0643\u0644\u0645 \u0639\u0646 \u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0647\u062F\u0641 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0644\u0645\u0627\u0630\u0627 \u062A\u0645 \u0635\u0646\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u062A\u0648\u0636\u064A\u062D \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0627\u0644\u0632\u0627\u0626\u0631 \u0639\u0646 \u0645\u0627\u0647\u064A\u0629 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
        link: "/register",
        map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.9951908772696!2d23.46773061482138!3d12.908030390897599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe2a4de30c8ff2fa!2zMTLCsDU0JzI4LjkiTiAyM8KwMjgnMTEuNyJF!5e0!3m2!1sen!2s!4v1640500796852!5m2!1sen!2s"
      }), /*#__PURE__*/jsx_runtime_.jsx(components_Space, {
        img: "/images/space-4.png",
        flip: true,
        title: t.spaces.spacesTitles[3],
        description: "\u0646\u0635 \u062A\u0639\u0631\u064A\u0641\u064A \u064A\u062A\u0643\u0644\u0645 \u0639\u0646 \u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0647\u062F\u0641 \u0627\u0644\u0645\u0633\u0627\u062D\u0647 \u0648\u0644\u0645\u0627\u0630\u0627 \u062A\u0645 \u0635\u0646\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u062A\u0648\u0636\u064A\u062D \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0627\u0644\u0632\u0627\u0626\u0631 \u0639\u0646 \u0645\u0627\u0647\u064A\u0629 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
        link: "/register",
        map: ""
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("section", {
      className: (Spaces_module_default()).reserve,
      children: /*#__PURE__*/jsx_runtime_.jsx(ReservationForm, {})
    })]
  });
};

async function getServerSideProps(ctx) {
  const jwt = (0,external_nookies_.parseCookies)(ctx).jwt !== undefined ? (0,external_nookies_.parseCookies)(ctx.jwt) : null;
  /* const api = process.env.NEXT_PUBLIC_API_URL;
  const res = await fetch(`${api}/dfc`);
  const content = await res.json(); */

  return {
    props: {
      // serverContent: content,
      jwt: jwt
    }
  };
}
/* harmony default export */ const spaces = (Spaces);

/***/ }),

/***/ 5279:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Reservation_container__1QPTR",
	"slogan": "Reservation_slogan__2h6y3",
	"main": "Reservation_main__2JRvj"
};


/***/ }),

/***/ 9749:
/***/ ((module) => {

// Exports
module.exports = {
	"space": "SpaceComponent_space__b2g_t",
	"info": "SpaceComponent_info__E0xsC",
	"info_icons": "SpaceComponent_info_icons__3onU9"
};


/***/ }),

/***/ 3681:
/***/ ((module) => {

// Exports
module.exports = {
	"spaces": "Spaces_spaces__3z_AG",
	"title": "Spaces_title__335xp",
	"description": "Spaces_description__1EQAB",
	"container": "Spaces_container__34CmA"
};


/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 5998:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [920,664,917,670], () => (__webpack_exec__(3189)));
module.exports = __webpack_exports__;

})();